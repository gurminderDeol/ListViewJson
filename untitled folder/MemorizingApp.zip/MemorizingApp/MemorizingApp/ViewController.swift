//
//  ViewController.swift
//  MemorizingApp
//
//  Created by Kiran Mehal on 2019-03-14.
//  Copyright © 2019 Kiran Mehal. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

